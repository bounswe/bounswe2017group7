request
=======

.. automodule:: goodreads.request
   :members:
   :undoc-members:
