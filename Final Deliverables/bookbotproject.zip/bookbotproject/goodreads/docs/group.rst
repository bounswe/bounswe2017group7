group
=======

.. automodule:: goodreads.group
   :members:
   :undoc-members:
