author
=======


.. automodule:: goodreads.author
   :members:
   :undoc-members:
